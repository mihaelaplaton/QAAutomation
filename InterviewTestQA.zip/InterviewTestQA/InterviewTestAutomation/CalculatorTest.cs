namespace InterviewTestQA
{
    public class CalculatorTest
    {
        [Fact]
        public void Test1()
        {

        }
    }
}